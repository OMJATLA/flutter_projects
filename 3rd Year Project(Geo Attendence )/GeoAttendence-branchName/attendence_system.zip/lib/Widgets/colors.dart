import 'package:flutter/material.dart';

const Color lightOrange = Color(0xffFFA624);
Color darkBlue = const Color(0xff034B60);
